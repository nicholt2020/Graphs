public class Vertex
   {
   public String label;        // label (e.g. 'A')
   public boolean isInTree;
// -------------------------------------------------------------
   public Vertex(String lab)   // constructor
      {
      label = lab;
      isInTree = false;
      }
   
      
// -------------------------------------------------------------
   }  // end class Vertex